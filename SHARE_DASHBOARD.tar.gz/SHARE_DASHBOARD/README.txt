STOCK MOVEMENT CONTEXT DASHBOARD

WHAT IS INCLUDED
- app.py: Streamlit dashboard
- charts.py: Plotly chart functions
- dso576_python/: backend analysis and canonical data validation
- requirements.txt: Python dependencies

DATA REQUIRED
The canonical data files were not available when this folder was prepared.
Before running the dashboard, put these four files in a data/cleaned folder:

  data/cleaned/prices.parquet
  data/cleaned/news.parquet
  data/cleaned/filings.parquet
  data/cleaned/price_context.parquet

Use the complete canonical files, not the sample CSVs. The app validates these
files and will show an error if they are missing or do not match the expected
full dataset.

RUN ON MAC OR LINUX
1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Run:

   python3 -m venv .venv
   source .venv/bin/activate
   python3 -m pip install -r requirements.txt
   streamlit run app.py

RUN ON WINDOWS POWERSHELL
1. Install Python 3.11 or newer.
2. Open PowerShell in this folder.
3. Run:

   py -m venv .venv
   .venv\Scripts\Activate.ps1
   py -m pip install -r requirements.txt
   streamlit run app.py

The dashboard then opens in the browser at the local address shown by Streamlit.
