"""Stock Movement Context Dashboard: cleaning, validation, and analysis."""
